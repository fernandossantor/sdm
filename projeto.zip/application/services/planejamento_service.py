from domain.models.plano_estrategico import (
    PlanoEstrategico,
    PlanoItem
)

from infrastructure.repositories.decision_repository import (
    DecisionRepository
)

from engine.inventory_engine import InventoryEngine
from engine.allocation_engine import AllocationEngine


class PlanejamentoService:

    def __init__(self):

        self.repository = DecisionRepository()

        self.inventory_engine = InventoryEngine()

        self.allocation_engine = AllocationEngine()

    # ======================================================
    # GERAR PLANO
    # ======================================================

    def gerar(self, nome_briefing):

        contexto = self.repository.carregar_contexto(
            nome_briefing
        )

        briefing = contexto["briefing"]

        objetivo = contexto["objetivo"]

        ranking = self.inventory_engine.calcular(
            contexto
        )

        distribuicao = self.allocation_engine.distribuir(
            ranking,
            briefing["orcamento"]
        )

        plano = PlanoEstrategico(

            cliente=briefing["anunciante"],

            campanha=briefing["nome"],

            objetivo=objetivo["nome"],

            orcamento=briefing["orcamento"]

        )

        for item in distribuicao:

            justificativas = self._gerar_justificativas(
                item
            )

            plano.adicionar_item(

                PlanoItem(

                    inventario=item["inventario"],

                    plataforma=item["plataforma"],

                    ambiente=item["ambiente"],

                    papel=item["papel"],

                    score=item["score"],

                    verba=item["verba"],

                    percentual=item["percentual"],

                    justificativas=justificativas

                )

            )

        plano.observacoes.append(

            "Plano gerado automaticamente pelo SDM."

        )

        plano.observacoes.append(

            "Distribuição baseada na aderência entre objetivo, audiência, KPI e métricas."

        )

        return plano

    # ======================================================
    # JUSTIFICATIVAS
    # ======================================================

    def _gerar_justificativas(self, item):

        justificativas = []

        if item["papel"] == "PRINCIPAL":

            justificativas.append(

                "Alta aderência ao objetivo da campanha."

            )

        elif item["papel"] == "COMPLEMENTAR":

            justificativas.append(

                "Complementa a cobertura dos canais principais."

            )

        elif item["papel"] == "APOIO":

            justificativas.append(

                "Reforça frequência e presença da campanha."

            )

        else:

            justificativas.append(

                "Baixa prioridade estratégica para este briefing."

            )

        if item["audiencia"] >= 4:

            justificativas.append(

                "Excelente aderência ao perfil de consumo da audiência."

            )

        elif item["audiencia"] >= 3:

            justificativas.append(

                "Boa aderência ao perfil da audiência."

            )

        if item["objetivo"] >= 4:

            justificativas.append(

                "Inventário fortemente recomendado para este objetivo."

            )

        if item["kpi"] >= 4:

            justificativas.append(

                "Bom desempenho histórico para o KPI selecionado."

            )

        if item["fator"] > 1:

            justificativas.append(

                "Métricas operacionais superiores à média."

            )

        return justificativas