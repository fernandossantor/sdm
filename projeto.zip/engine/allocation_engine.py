class AllocationEngine:

    # ======================================================
    # DISTRIBUIÇÃO DE VERBA
    # ======================================================

    def distribuir(
        self,
        ranking,
        verba_total
    ):

        ranking = [
            item
            for item in ranking
            if item["score"] > 0
        ]

        if not ranking:

            return []

        total_score = sum(

            item["score"]

            for item in ranking

        )

        resultado = []

        for item in ranking:

            percentual = (

                item["score"]

                / total_score

            )

            verba = (

                percentual

                * verba_total

            )

            resultado.append(

                {

                    "inventario": item["inventario"],

                    "plataforma": item["plataforma"],

                    "ambiente": item["ambiente"],

                    "papel": item["papel"],

                    "score": item["score"],

                    "objetivo": item["objetivo"],

                    "kpi": item["kpi"],

                    "audiencia": item["audiencia"],

                    "fator": item["fator"],

                    "percentual": percentual * 100,

                    "verba": verba

                }

            )

        return resultado