class InventoryEngine:

    # ==========================================================
    # INDEXADORES
    # ==========================================================

    def indexar_objetivos(self, dados):

        indice = {}

        for item in dados:

            indice[
                (
                    item["inventario_id"],
                    item["objetivo_id"]
                )
            ] = item

        return indice

    # ==========================================================

    def indexar_kpis(self, dados):

        indice = {}

        for item in dados:

            indice[
                (
                    item["inventario_id"],
                    item["kpi_id"]
                )
            ] = item

        return indice

    # ==========================================================

    def indexar_metricas(self, dados):

        indice = {}

        for item in dados:

            indice[
                item["inventario_id"]
            ] = item

        return indice

    # ==========================================================

    def indexar_consumo(self, dados):

        indice = {}

        for item in dados:

            indice[
                (
                    item["audiencia_id"],
                    item["ambiente_id"]
                )
            ] = item

        return indice

    # ==========================================================
    # MÉTRICAS
    # ==========================================================

    def fator_metricas(self, metricas):

        fator = 1.0

        if metricas is None:

            return fator

        ctr = metricas.get("ctr")

        if ctr is not None:

            if ctr >= 2:

                fator *= 1.10

            elif ctr >= 1:

                fator *= 1.05

        view = metricas.get("viewability")

        if view is not None:

            if view >= 80:

                fator *= 1.10

            elif view >= 70:

                fator *= 1.05

        freq = metricas.get("frequencia_media")

        if freq is not None:

            if 3 <= freq <= 6:

                fator *= 1.05

        return fator

    # ==========================================================
    # PAPEL
    # ==========================================================

    def classificar_papel(self, score):

        if score >= 20:

            return "PRINCIPAL"

        elif score >= 10:

            return "COMPLEMENTAR"

        elif score >= 5:

            return "APOIO"

        return "OPCIONAL"

    # ==========================================================
    # ENGINE
    # ==========================================================

    def calcular(self, contexto):

        briefing = contexto["briefing"]

        objetivo = contexto["objetivo"]

        audiencia = contexto["audiencias"][0]["audiencia_id"]

        inventarios = contexto["inventarios"]

        idx_obj = self.indexar_objetivos(

            contexto["inventarios_objetivos"]

        )

        idx_kpi = self.indexar_kpis(

            contexto["inventarios_kpis"]

        )

        idx_metricas = self.indexar_metricas(

            contexto["metricas"]

        )

        idx_consumo = self.indexar_consumo(

            contexto["consumo"]

        )

        resultado = []

        #
        # Descobre o KPI do briefing
        #

        nome_kpi = briefing["kpi"]

        #
        # Precisaremos do ID do KPI
        #

        kpi_id = None

        for item in contexto["inventarios_kpis"]:

            #
            # Este trecho será eliminado na próxima release,
            # quando o repository carregar também kpis_v3.
            #

            if "kpis_v3" in item:

                if item["kpis_v3"]["nome"] == nome_kpi:

                    kpi_id = item["kpi_id"]

                    break

        #
        # Loop principal
        #

        for inventario in inventarios:

            ambiente_id = inventario["ambiente_id"]

            #
            # Audiência
            #

            score_aud = 1

            consumo = idx_consumo.get(

                (

                    audiencia,

                    ambiente_id

                )

            )

            if consumo:

                score_aud = float(

                    consumo["score"]

                )

            #
            # Objetivo
            #

            rel_obj = idx_obj.get(

                (

                    inventario["id"],

                    objetivo["id"]

                )

            )

            if rel_obj:

                score_obj = rel_obj["score_base"]

                peso_obj = float(

                    rel_obj["peso_manual"]

                )

            else:

                score_obj = 0

                peso_obj = 1

            #
            # KPI
            #

            score_kpi = 0

            peso_kpi = 1

            if kpi_id:

                rel_kpi = idx_kpi.get(

                    (

                        inventario["id"],

                        kpi_id

                    )

                )

                if rel_kpi:

                    score_kpi = rel_kpi["score_base"]

                    peso_kpi = float(

                        rel_kpi["peso_manual"]

                    )

            #
            # Métricas
            #

            metricas = idx_metricas.get(

                inventario["id"]

            )

            fator = self.fator_metricas(

                metricas

            )

            #
            # Score
            #

            score = (

                score_obj

                * peso_obj

                * score_kpi

                * peso_kpi

                * score_aud

                * fator

            )

            resultado.append(

                {

                    "inventario":

                        inventario["nome"],

                    "plataforma":

                        inventario["plataformas_v3"]["nome"],

                    "ambiente":

                        inventario["ambientes_v3"]["nome"],

                    "score":

                        round(score, 2),

                    "papel":

                        self.classificar_papel(score),

                    "objetivo":

                        score_obj,

                    "kpi":

                        score_kpi,

                    "audiencia":

                        score_aud,

                    "fator":

                        round(fator, 2)

                }

            )

        resultado.sort(

            key=lambda x: x["score"],

            reverse=True

        )

        return resultado