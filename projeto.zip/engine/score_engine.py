from infrastructure.database.admin_client import admin

from engine.models import AmbienteScore


# =====================================================
# SCORE CALCULATOR
# =====================================================

class ScoreCalculator:

    @staticmethod
    def calcular(

        score_objetivo: float,

        score_consumo: float,

        peso_audiencia: float,

        peso_cenario: float = 1.0

    ) -> float:

        return (

            score_objetivo

            *

            score_consumo

            *

            peso_audiencia

            *

            peso_cenario

        )


# =====================================================
# CLASSIFICAÇÃO
# =====================================================

def classificar_papel(score: float) -> str:

    if score >= 20:

        return "PRINCIPAL"

    elif score >= 12:

        return "COMPLEMENTAR"

    elif score >= 4:

        return "APOIO"

    return "RESIDUAL"


# =====================================================
# CONSULTAS
# =====================================================

def obter_consumo(audiencia_id):

    r = (

        admin

        .table("consumo_midia_v3")

        .select("*")

        .eq("audiencia_id", audiencia_id)

        .execute()

    )

    return r.data


def obter_scores_objetivo(objetivo_id):

    r = (

        admin

        .table("objetivos_ambientes_v3")

        .select("*")

        .eq("objetivo_id", objetivo_id)

        .execute()

    )

    return r.data


def obter_nome_ambiente(ambiente_id):

    r = (

        admin

        .table("ambientes_v3")

        .select("nome")

        .eq("id", ambiente_id)

        .execute()

    )

    return r.data[0]["nome"]


# =====================================================
# ENGINE
# =====================================================

def calcular_scores(

    objetivo,

    audiencias

):

    ranking = []


    ambientes_objetivo = obter_scores_objetivo(

        objetivo.id

    )


    mapa_objetivo = {

        a["ambiente_id"]: float(a["score_base"])

        for a in ambientes_objetivo

    }


    for audiencia in audiencias:


        consumo = obter_consumo(

            audiencia.audiencia_id

        )


        for c in consumo:


            ambiente_id = c["ambiente_id"]


            if ambiente_id not in mapa_objetivo:

                continue


            score_objetivo = mapa_objetivo[ambiente_id]


            if score_objetivo == 0:

                continue


            score = ScoreCalculator.calcular(

                score_objetivo,

                float(c["score"]),

                audiencia.peso

            )


            ranking.append(

                AmbienteScore(

                    ambiente_id=ambiente_id,

                    ambiente=obter_nome_ambiente(

                        ambiente_id

                    ),

                    score=score,

                    papel=classificar_papel(

                        score

                    )

                )

            )


    ranking.sort(

        key=lambda x: x.score,

        reverse=True

    )


    return ranking