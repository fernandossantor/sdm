import streamlit as st

from infrastructure.database.supabase_client import supabase


st.set_page_config(
    page_title="Catálogos",
    layout="wide"
)

st.title("📚 Catálogos")

st.markdown("---")


def carregar_tabela(nome_tabela):

    try:

        response = (
            supabase
            .table(nome_tabela)
            .select("*")
            .execute()
        )

        dados = response.data

        if dados:

            st.success(f"{len(dados)} registros encontrados")

            st.dataframe(
                dados,
                width="stretch"
            )

        else:

            st.warning("Tabela vazia.")

    except Exception as erro:

        st.error(f"Erro: {erro}")


abas = st.tabs([
    "Canais",
    "Ambientes",
    "Estruturas",
    "Formatos",
    "Tecnologias",
    "Perfis",
    "Modalidades",
    "Unidades",
    "KPIs"
])


with abas[0]:

    carregar_tabela("canais")


with abas[1]:

    carregar_tabela("ambientes")


with abas[2]:

    carregar_tabela("estruturas")


with abas[3]:

    carregar_tabela("formatos")


with abas[4]:

    carregar_tabela("tecnologias")


with abas[5]:

    carregar_tabela("perfis_editoriais")


with abas[6]:

    carregar_tabela("modalidades_compra")


with abas[7]:

    carregar_tabela("unidades_compra")


with abas[8]:

    carregar_tabela("kpis")