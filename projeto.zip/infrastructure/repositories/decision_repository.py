from infrastructure.database.admin_client import admin


class DecisionRepository:

    # =====================================================
    # BRIEFING
    # =====================================================

    def briefing(self, nome):

        return (
            admin
            .table("briefings_v3")
            .select("*")
            .eq("nome", nome)
            .single()
            .execute()
            .data
        )

    # =====================================================
    # OBJETIVO
    # =====================================================

    def objetivo(self, objetivo_id):

        return (
            admin
            .table("objetivos_campanha_v3")
            .select("*")
            .eq("id", objetivo_id)
            .single()
            .execute()
            .data
        )

    # =====================================================
    # AUDIÊNCIAS
    # =====================================================

    def audiencias(self, briefing_id):

        return (
            admin
            .table("briefing_audiencias_v3")
            .select("*")
            .eq("briefing_id", briefing_id)
            .execute()
            .data
        )

    # =====================================================
    # INVENTÁRIOS
    # =====================================================

    def inventarios(self):

        return (
            admin
            .table("inventarios_v3")
            .select("""
                id,
                nome,
                descricao,

                plataforma_id,
                ambiente_id,
                formato_id,

                plataformas_v3(
                    id,
                    nome
                ),

                ambientes_v3(
                    id,
                    nome
                ),

                formatos_v3(
                    id,
                    nome
                )

            """)
            .execute()
            .data
        )

    # =====================================================
    # INVENTÁRIO x OBJETIVO
    # =====================================================

    def inventarios_objetivos(self):

        return (
            admin
            .table("inventarios_objetivos_v3")
            .select("*")
            .execute()
            .data
        )

    # =====================================================
    # INVENTÁRIO x KPI
    # =====================================================

    def inventarios_kpis(self):

        return (
            admin
            .table("inventarios_kpis_v3")
            .select("*")
            .execute()
            .data
        )

    # =====================================================
    # MÉTRICAS
    # =====================================================

    def metricas(self):

        return (
            admin
            .table("inventarios_metricas_v3")
            .select("*")
            .execute()
            .data
        )

    # =====================================================
    # CONSUMO
    # =====================================================

    def consumo(self):

        return (
            admin
            .table("consumo_midia_v3")
            .select("*")
            .execute()
            .data
        )

    # =====================================================
    # CONTEXTO
    # =====================================================

    def carregar_contexto(self, nome_briefing):

        briefing = self.briefing(nome_briefing)

        return {

            "briefing": briefing,

            "objetivo": self.objetivo(
                briefing["objetivo_id"]
            ),

            "audiencias": self.audiencias(
                briefing["id"]
            ),

            "inventarios": self.inventarios(),

            "inventarios_objetivos":
                self.inventarios_objetivos(),

            "inventarios_kpis":
                self.inventarios_kpis(),

            "metricas":
                self.metricas(),

            "consumo":
                self.consumo()

        }